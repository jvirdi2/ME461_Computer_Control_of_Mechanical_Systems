/******************************************************************************
MSP430F2272 Project Creator 4.0

ME 461 - S. R. Platt
Fall 2010

Updated for CCSv4.2 Rick Rekoske 8/10/2011

Written by: Steve Keres
College of Engineering Control Systems Lab
University of Illinois at Urbana-Champaign
*******************************************************************************/

#include "msp430x22x2.h"
#include "UART.h"

char newprint = 0;
char states=0;
unsigned int timecnt = 0;
unsigned int fastcnt = 0;
float temp=0;
float temp2=0;
int counter0 = 0;
char counter1 = 0;
char counter2 = 0;
char counter3 = 0;
// Create your global variables here:

//char readswitches(void){
//    //char out = P2IN;
//    //out = out>>4;
//    //out=out ^ 0xC;
//    char out= 0x0;
//    if ((P2IN &=0x10)==0x10){
//        out |= 0x1;
//    }
//    if ((P2IN &=0x20)==0x20){
//            out |= 0x2;
//        }
//    if ((P2IN &=0x40)==0x00){
//            out |= 0x4;
//        }
//    if ((P2IN &=0x80)==0x00){
//            out |= 0x8;
//        }
//
//    return(out);
//}

----void main(void) {
	
	WDTCTL = WDTPW + WDTHOLD; // Stop WDT
	
	if (CALBC1_16MHZ ==0xFF || CALDCO_16MHZ == 0xFF) while(1);
	                                             
	DCOCTL  = CALDCO_16MHZ; // Set uC to run at approximately 16 Mhz
	BCSCTL1 = CALBC1_16MHZ; 
		
	//P1IN 		    Port 1 register used to read Port 1 pins setup as Inputs
	P1SEL &= ~0xFF; // Set all Port 1 pins to Port I/O function
	P1REN &= ~0xFF; // Disable internal resistor for all Port 1 pins
	P1DIR |= 0xFF;   // Set Port 1 Pin 0 (P1.0) as an output.  Leaves Port1 pin 1 through 7 unchanged
	P1OUT &= ~0xFF; // Initially set all Port 1 pins set as Outputs to zero

	// Timer A Config
	TACCTL0 = CCIE;              // Enable Timer A interrupt
	TACCR0  = 16000;             // period = 1ms   
	TACTL   = TASSEL_2 + MC_1;   // source SMCLK, up mode
	
    P2SEL=0x0;
    P2DIR=0x0;
    P2REN=0xF0;
    P2OUT=0xC0;

    P2IFG = 0x00;
    P2IE = 0xF0;
    P2IES = 0xC0;


	Init_UART(115200, 1);	// Initialize UART for 9600 baud serial communication

	_BIS_SR(GIE); 	    // Enable global interrupt

	while(1) {

	    if(newmsg) {
	        //my_scanf(rxbuff,&var1,&var2,&var3,&var4);
	        //my_scanf(rxbuff,&temp);
	        //timecnt = (unsigned int)temp;
	        newmsg = 0;
	    }

	    if (newprint)  {

//	        states=readswitches();

//	        if (states==0x00){
//	            P1OUT ^=0xFF;
//	        }
//	        else{
//	            P1OUT ^= states; // Blink LED
//	            P1OUT &= states;
//	        }
	        UART_printf("%d,%d,%d,%d\n\r ",(int)counter0,(int)counter1,(int)counter2,(int)counter3); //  %d int, %ld long, %c char, %x hex form, %.3f float 3 decimal place, %s null terminated character array

	        //UART_send(2,(float)timecnt,(float)temp2);
	        newprint = 0;
	    }

	}
}


// Timer A0 interrupt service routine

//Port 2 interrupt service routine
#pragma vector=PORT2_VECTOR
__interrupt void Port_2(void) {
    if ((P2IFG&0x10)==0x10){
        counter0++;
        P2IFG &= ~0x10;
    }
    if ((P2IFG&0x20)==0x20){
        counter0++;
        P2IFG &= ~0x30;
    }
    if ((P2IFG&0x40)==0x40){
        counter0--;
        P2IFG &= ~0x40;
    }
    if ((P2IFG&0x80)==0x80){
        counter0--;
        P2IFG &= ~0x80;
    }

}


#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A (void)
{
    int time = 800 + 32*counter0;
	fastcnt++; // Keep track of time for main while loop. 
	if (fastcnt == time) {
		fastcnt = 0;
		newprint = 1;  // flag main while loop that .5 seconds have gone by.  
	}
	if (fastcnt < time/8){
	    P1OUT = 0x01;
	}
	if (fastcnt < 2*time/8 & fastcnt > time/8){
	    P1OUT = 0x02;
	}
	if (fastcnt < 3*time/8 & fastcnt > 2*time/8){
	    P1OUT = 0x04;
	}
	if (fastcnt < 4*time/8 & fastcnt > 3*time/8){
	    P1OUT = 0x08;
	}
	if (fastcnt < 5*time/8 & fastcnt > 4*time/8){
	    P1OUT = 0x10;
	}
	if (fastcnt < 6*time/8 & fastcnt > 5*time/8){
	    P1OUT = 0x20;
	}
	if (fastcnt < 7*time/8 & fastcnt > 6*time/8){
	    P1OUT = 0x40;
	}
	if (fastcnt < 8*time/8 & fastcnt > 7*time/8){
	    P1OUT = 0x80;
	}

	// Put your Timer_A code here:

  
}


/*
// ADC 10 ISR - Called when a sequence of conversions (A7-A0) have completed
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void) {
	
}
*/


// USCI Transmit ISR - Called when TXBUF is empty (ready to accept another character)
#pragma vector=USCIAB0TX_VECTOR
__interrupt void USCI0TX_ISR(void) {
  
	if((IFG2&UCA0TXIFG) && (IE2&UCA0TXIE)) { // USCI_A0 requested TX interrupt
		if(printf_flag) {
			if (currentindex == txcount) {
				senddone = 1;
				printf_flag = 0;
				IFG2 &= ~UCA0TXIFG;
			} else {
			UCA0TXBUF = printbuff[currentindex];
			currentindex++;
			}
		} else if(UART_flag) {
			if(!donesending) {
				UCA0TXBUF = txbuff[txindex];
				if(txbuff[txindex] == 255) {
					donesending = 1;
					txindex = 0;
				} else {
					txindex++;
				}
			}
		}
	    
		IFG2 &= ~UCA0TXIFG;
	}

	if((IFG2&UCB0TXIFG) && (IE2&UCB0TXIE)) { // USCI_B0 requested TX interrupt (UCB0TXBUF is empty)
		
		IFG2 &= ~UCB0TXIFG;   // clear IFG
	}
}


// USCI Receive ISR - Called when shift register has been transferred to RXBUF
// Indicates completion of TX/RX operation
#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void) {
  
	if((IFG2&UCA0RXIFG) && (IE2&UCA0RXIE)) { // USCI_A0 requested RX interrupt (UCA0RXBUF is full)
  	
		if(!started) {	// Haven't started a message yet
			if(UCA0RXBUF == 253) {
				started = 1;
				newmsg = 0;
			}
		} else { // In process of receiving a message		
			if((UCA0RXBUF != 255) && (msgindex < (MAX_NUM_FLOATS*5))) {
				rxbuff[msgindex] = UCA0RXBUF;
				
				msgindex++;
			} else { // Stop char received or too much data received
				if(UCA0RXBUF == 255) { // Message completed
					newmsg = 1;
					rxbuff[msgindex] = 255;	// "Null"-terminate the array
				}
				started = 0;
				msgindex = 0;
			}
		}
		IFG2 &= ~UCA0RXIFG;
	}
	
	if((IFG2&UCB0RXIFG) && (IE2&UCB0RXIE)) { // USCI_B0 requested RX interrupt (UCB0RXBUF is full)

		IFG2 &= ~UCB0RXIFG; // clear IFG
	}
  
}



